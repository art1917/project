<?php $__env->startSection('content'); ?>
<title>Edit Data Kategori</title>
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
            <form action="/kategori/update" method="post">
                    <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label for="">Kategori</label>
                    <input type="text" name="nama_kategori" class="form-control" value="<?php echo e($kategori->nama_kategori); ?>" required placeholder="Masukan kategori">
                    <input type="hidden" name="id_kategori" class="form-control" value="<?php echo e($kategori->id_kategori); ?>" required placeholder="Masukan Jenis">
                  </div>
                </div>
                  <button type="submit" class="btn btn-primary">Update</button>
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/kategori/edit.blade.php ENDPATH**/ ?>