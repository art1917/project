<?php $__env->startSection('content'); ?>
<title>Data Keranjang Barang Masuk</title>
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Data Keranjang Barang Masuk</h6>
</div>
<div class="card-body">
  <div class="table-responsive">
    <a href="/keranjang_masuk/form_input" class="btn btn-success">Tambah Data</a>
      <br>
      <br>
      <table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                  <th>No</th>
                  <th>Barang</th>
                  <th>Jumlah</th>
                  <th>Tanggal Masuk</th>
                  <th>Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="data-row">
                  <td><?php echo e(++$i); ?></td>
                  <td><?php echo e($u->nama_barang); ?></td>
                  <td><?php echo e($u->jumlah_asup); ?></td>
                  <td><?php echo e($u->tanggal_masuk); ?></td>
                  
              <td>  
                <div class="row">
                   <a href="/keranjang_masuk/edit/<?php echo e($u->id_masuk); ?>" class="btn btn-primary btn-sm ml-2">Edit</a>
                   <a href="/keranjang_masuk/hapus/<?php echo e($u->id_masuk); ?>" class="btn btn-danger btn-sm ml-2">Hapus</a>
                   <a href="/keranjang_masuk/detail_masuk/<?php echo e($u->id_masuk); ?>" class="btn btn-warning btn-sm ml-2">Detail</a>
                </div>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
  </div>
  <div class="text-center">
  <a href="/inputmasuk" class="btn btn-dark">Masukan Semua Data</a>
  </div>
  <br>
   <font><b>*Mohon untuk langsung klik masukkan semua data untuk memasukan ke dalam data barang masuk</b></font>
</div>
  
  
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/keranjang_masuk/view.blade.php ENDPATH**/ ?>