 <?php $__env->startSection('content'); ?>
<title>Detail Peminjaman</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Detail Peminjaman</h6>
</div>
<div class="card-body">
    <div class="x_content">
        <table>
            <thead>
                <tr>
                    <th>Nama Peminjam</th>
                    <th>:</th>
                    <td><?php echo e($peminjaman2->nama_peminjam); ?></td>
                </tr>
                <tr>
                    <th>Nama Barang</th>
                    <th>:</th>
                     <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($peminjaman2->id_barang==$r->id_barang): ?>
                    <td><?php echo e($r->nama_barang); ?></td>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                 <tr>
                    <th>Jumlah</th>
                    <th>:</th>
                    <td><?php echo e($peminjaman2->jumlah_pinjam); ?></td>
                </tr>
                <tr>
                    <th>Tanggal Peminjaman</th>
                    <th>:</th>
                    <td><?php echo e($peminjaman2->tanggal_pinjam); ?></td>
                </tr>
                <tr>
                    <th>Tanggal Kembali</th>
                    <th>:</th>
                    <td><?php echo e($peminjaman2->tanggal_kembali); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <th>:</th>
                    <td><?php echo e($peminjaman2->status); ?></td>
                </tr>
            </thead>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/peminjaman/detail.blade.php ENDPATH**/ ?>