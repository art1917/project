<?php $__env->startSection('content'); ?>
<title>Edit Data Ruangan</title>
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
            <form action="/ruangan/update" method="post">
                    <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label for="">ruangan</label>
                    <input type="text" name="ruangan" class="form-control" value="<?php echo e($ruangan->ruangan); ?>" required placeholder="Masukan ruangan">
                    <input type="hidden" name="id_ruangan" class="form-control" value="<?php echo e($ruangan->id_ruangan); ?>" required placeholder="Masukan Jenis">
                  </div>
                  <div class="form-group">
                <label for="">Pembimbing</label>
                <select name="id_pembimbing"  id="" class="form-control" >
                  <option value="" selected disabled>Pilih Pembimbing</option>
                  <?php $__currentLoopData = $pembimbing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($a->id); ?>" <?php echo e($a->id==$ruangan->id_pembimbing ? 'selected' : ''); ?>><?php echo e($a->name); ?></option>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="">Pj</label>
                <select name="id_pj" class="form-control" id="" >
                  <option value="" selected disabled>Pilih Pj</option>
                  <?php $__currentLoopData = $pj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($b->id); ?>" <?php echo e($b->id==$ruangan->id_pj ? 'selected' : ''); ?>><?php echo e($b->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            </
                </div>
                
          </div>
                  <button type="submit" class="btn btn-primary">Update</button>
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\xampp\htdocs\laravel_sarpras\resources\views/ruangan/edit.blade.php ENDPATH**/ ?>