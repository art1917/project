<table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                  <th>Barang</th>
                  <th>Jumlah</th>
                  <th>Tujuan</th>
                  <th>Tanggal Keluar</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($m->nama_barang); ?></td>
                  <td><?php echo e($m->jumlah_keluar); ?></td>
                  <td><?php echo e($m->untuk); ?></td>
                  <td><?php echo e($m->tanggal_keluar); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table><?php /**PATH D:\xampp\htdocs\laravel_sarpras\resources\views/laporan/table_keluar.blade.php ENDPATH**/ ?>