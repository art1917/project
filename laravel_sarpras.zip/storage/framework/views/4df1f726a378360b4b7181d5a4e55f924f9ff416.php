 <?php $__env->startSection('content'); ?>
<title>Edit Data</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
        <form action="/keranjang_ruangan/update" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="">Ruangan</label>
                <input type="hidden" name="id_input_ruangan" value="<?php echo e($input_ruangan2->id_input_ruangan); ?>">
                <select name="id_ruangan" id="" class="form-control">
                 <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($input_ruangan2->id_ruangan==$r->id_ruangan): ?>
                  <option value="<?php echo e($r->id_ruangan); ?>" selected="selected"><?php echo e($r->ruangan); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($r->id_ruangan); ?>"><?php echo e($r->ruangan); ?></option>
                      <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>              
        </div>
            <div class="form-group">
                <label for="">Barang</label>
               <select name="id_barang" id="" class="form-control">
                 <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($input_ruangan2->id_barang==$r->id_barang): ?>
                  <option value="<?php echo e($r->id_barang); ?>" selected="selected"><?php echo e($r->nama_barang); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($r->id_barang); ?>"><?php echo e($r->nama_barang); ?></option>
                      <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
            </div>

            <div class="form-group">
                <label for="">Jumlah</label>
                <input type="number" name="jumlah" class="form-control" value="<?php echo e($input_ruangan2->jumlah_masuk); ?>" required placeholder="Masukan Jumlah">
            </div>
            <div class="form-group">
                <label for="">Tanggal Masuk</label>
                <input type="date" name="tanggal_masuk" class="form-control" value="<?php echo e($input_ruangan2->tanggal_masuk); ?>" required placeholder="Masukan Ruangan">
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/keranjang_ruangan/edit.blade.php ENDPATH**/ ?>