<?php $__env->startSection('content'); ?>
<title>Dashboard</title>
<div class="card-header">
     <?php if(Auth::user()->level=='rayon'): ?>
        Dashboard Pembimbing
    <?php elseif(Auth::user()->level=='pj'): ?>
        Dashboard Pj Ruangan
    <?php else: ?>
        Dashboard
    <?php endif; ?>
</div>
<div class="card-body">
    <h1 align="center">Sistem Manajemen Sarana & Prasarana</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/pembimbing/dashboard_pem.blade.php ENDPATH**/ ?>