<?php $__env->startSection('content'); ?>
<title>Laporan Data Barang Masuk</title>
</div>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-dark">Masukan Tanggal Awal dan Akhir</h6>
    </div>
    <div class="card-body">
        <form action="lap_barang_masuk_input" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Tanggal Awal</label>
                        <input type="date" name="awal" required class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Tanggal Akhir</label>
                        <input type="date" name="akhir" required class="form-control">
                    </div>
                </div>
            </div>
            <center><input type="submit" class="btn btn-success"></center>
      </form>
<br>
    </div>
</div>
<div class="card shadow mb-4">
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Laporan Data Barang Masuk</h6>
</div>
<div class="card-body">
  <div class="table-responsive">
     <?php if($hitung == 0): ?>
        
    <?php else: ?>
    
    <form action="/lap_barang_masuk/export_excel">
        <input type="hidden" name="awal" value="<?php echo e($req1); ?>">
        <input type="hidden" name="akhir" value="<?php echo e($req2); ?>">
       <input type="submit" class="btn btn-warning" value="EXPORT EXCEL">
       
       </form>
    <?php endif; ?>
       <br>
    <?php echo $__env->make('laporan.table_masuk', $masuk , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\xampp\htdocs\laravel_sarpras\resources\views/laporan/barang_masuk.blade.php ENDPATH**/ ?>