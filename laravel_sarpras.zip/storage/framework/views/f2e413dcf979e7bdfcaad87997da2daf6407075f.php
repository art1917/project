 <?php $__env->startSection('content'); ?>
<title>Edit Data</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
        <form action="/rusak_luar/update" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id_rusak_luar" value="<?php echo e($rusak_luar2->id_rusak_luar); ?>">
            <div class="form-group">
                <label for="">Barang</label>
                 <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($rusak_luar2->id_barang_rusak_luar==$r->id_barang): ?>
                <input type="hidden" name="id_barang" value="<?php echo e($r->id_barang); ?>" readonly class="form-control">
                <input type="text" value="<?php echo e($r->nama_barang); ?>" readonly class="form-control">
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="form-group">
                <label for="">Jumlah</label>
                <input type="number" name="jumlah" class="form-control" value="<?php echo e($rusak_luar2->jumlah_rusak_luar); ?>" required placeholder="Masukan Jumlah">
            </div>
            <div class="form-group">
                <label for="">Tanggal Masuk</label>
                <input type="date" name="tanggal_rusak" class="form-control" value="<?php echo e($rusak_luar2->tanggal_rusak_luar); ?>" required placeholder="Masukan Ruangan">
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/rusak_luar/edit.blade.php ENDPATH**/ ?>