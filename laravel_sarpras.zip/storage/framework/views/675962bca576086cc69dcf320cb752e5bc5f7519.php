<table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                  <th>No</th>
                  <th>No Peminjaman</th>
                  <th>Nama Peminjam</th>
                  <th>Barang</th>
                  <th>Jumlah</th>
                  <th>Tanggal Pinjam</th>
                  <th>Tanggal Kembali</th>
                  <th>Status</th>
                  <?php echo $__env->yieldContent('opsi'); ?>
                  
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="data-row">
                  <td><?php echo e(++$i); ?></td>
                  <td><?php echo e($u->no_peminjaman); ?></td>
                  <td><?php echo e($u->nama_peminjam); ?></td>
                  <td><?php echo e($u->nama_barang); ?></td>
                  <td><?php echo e($u->jumlah_pinjam); ?></td>
                  <td><?php echo e($u->tanggal_pinjam); ?></td>
                  <td><?php echo e($u->tanggal_kembali); ?></td>
                  <td><?php echo e($u->status); ?></td>
                  <?php echo $__env->yieldContent('isi'); ?>
              
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/peminjaman/table.blade.php ENDPATH**/ ?>