<table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                  <th>Ruangan</th>
                  <th>Barang</th>
                  <th>Jumlah Baik</th>
                  <th>Jumlah Rusak</th>
                  <th>Total</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $inputruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($m->ruangan); ?></td>
                  <td><?php echo e($m->nama_barang); ?></td>
                  <td><?php echo e($m->jumlah_masuk); ?></td>
                  <td><?php echo e($m->jumlah_rusak_ruangan); ?></td>
                  <td><?php echo e($m->jumlah_rusak_ruangan + $m->jumlah_masuk); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table><?php /**PATH D:\xampp\htdocs\laravel_sarpras\resources\views/laporan/table_ruangan.blade.php ENDPATH**/ ?>