<?php $__env->startSection('content'); ?>
<title>Laporan Rusak</title>
</div>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-dark">Masukan Tanggal</h6>
    </div>
    <div class="card-body">
        <form action="lap_rusak_luar_input" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Tanggal Awal</label>
                        <input type="date" name="awal" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Tanggal Akhir</label>
                        <input type="date" name="akhir" required class="form-control">
                    </div>
                </div>
                 <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Status</label>
                        <select name="status" class="form-control" required>
                            <option value=""selected disabled>Pilih Status</option>
                            <option value="rusak">Rusak</option>
                            <option value="sudah_diperbaiki">Sudah Di Perbaiki</option>
                        </select>
                    </div>
                </div>
            </div>
            <center><input type="submit" class="btn btn-success"></center>
      </form>
<br>
    </div>
</div>
<div class="card shadow mb-4">
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Laporan Data Peminjaman</h6>
</div>
<div class="card-body">
  <div class="table-responsive">
    
      
     <?php if($hitung == 0): ?>
        
    <?php else: ?>
    
    <form action="/lap_rusak_luar/export_excel">
        <input type="hidden" name="awal" value="<?php echo e($req1); ?>">
        <input type="hidden" name="akhir" value="<?php echo e($req2); ?>">
        <input type="hidden" name="status" value="<?php echo e($req3); ?>">
       <input type="submit" class="btn btn-warning" value="EXPORT EXCEL">
       
       </form>
    <?php endif; ?>
       <br>
    <?php echo $__env->make('laporan.table_rusak_luar', $rusak_luar , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
  </div>
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/laporan/barang_rusak_luar.blade.php ENDPATH**/ ?>