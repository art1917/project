 <?php $__env->startSection('content'); ?>
<title>Edit Data</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
        <form action="/keranjang_rusak_ruangan/update" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="">Ruangan</label>
                <input type="hidden" name="id_rusak_ruangan" value="<?php echo e($rusak2->id_rusak_ruangan); ?>">
                <select name="id_ruangan" id="" class="form-control">
                 <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($rusak2->id_ruangan_rusak==$r->id_ruangan): ?>
                  <option value="<?php echo e($r->id_ruangan); ?>" selected="selected"><?php echo e($r->ruangan); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($r->id_ruangan); ?>"><?php echo e($r->ruangan); ?></option>
                      <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>              
        </div>
            <div class="form-group">
                <label for="">Barang</label>
               <select name="id_barang" id="" class="form-control">
                 <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($rusak2->id_barang_rusak==$r->id_barang): ?>
                  <option value="<?php echo e($r->id_barang); ?>" selected="selected"><?php echo e($r->nama_barang); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($r->id_barang); ?>"><?php echo e($r->nama_barang); ?></option>
                      <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
            </div>

            <div class="form-group">
                <label for="">Jumlah Rusak</label>
                <input type="number" name="jumlah" class="form-control" value="<?php echo e($rusak2->jumlah_rusak_ruangan); ?>" required placeholder="Masukan Jumlah">
            </div>
            <div class="form-group">
                <label for="">Tanggal Rusak</label>
                <input type="date" name="tanggal_rusak" class="form-control" value="<?php echo e($rusak2->tanggal_rusak); ?>" required placeholder="Masukan Ruangan">
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/keranjang_rusak_ruangan/edit.blade.php ENDPATH**/ ?>