 <?php $__env->startSection('content'); ?>
<title>Input Data</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Input Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
        <form action="/keranjang_masuk/store" method="post">
            <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="">Pilih Kategori Barang</label>
              <select name="kategori" id="" class="form-control">
                  <option value="" selected disabled>Pilih Kategori barang</option>
                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nama_kategori); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="form-group">
             <div class="input_fields_wrap">
            
            <table>
              <tr>
                <td>
                  <label for="">Nama Barang</label>
                      <select name="id_barang" id="" class="form-control">
                          <option selected disabled>Pilih Barang</option>
                          <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($j->id_barang); ?>"><?php echo e($j->nama_barang); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </select>
                    </div>
                </td>
                <td class="pl-2">
                    <label for="">Jumlah</label>
                    <input type="number" name="jumlah" id="txt1[]" onkeyup="sum();" class="form-control" required placeholder="Masukan Jumlah" required>
                </td>
                <td class="pl-2">
                    <label for="">Harga Satuan</label>
                    <input type="number" name="harga_satuan" id="txt2[]" onkeyup="sum();" class="form-control" required placeholder="Masukan Jumlah" required>
                </td>
                <td class="pl-2">
                    <label for="">Harga Total</label>
                    <input type="number" name="harga_total" id="txt3[]"  class="form-control" required placeholder="Masukan Jumlah" required>
                </td>
                <td class="pl-2">
                    <label for="">Nama Toko</label>
                    <input type="text" name="nama_toko" class="form-control" required placeholder="Masukan Jumlah" required>
                </td>
                <td class="pl-2">
                    <label for="">Merek</label>
                    <input type="text" name="merek" class="form-control" required placeholder="Masukan Jumlah" required>
                </td>
              </tr>
            </table>
              
          </div>
          <div class="form-group">
              <label for="">Sumber Dana</label>
                <input type="text" name="sumber_dana" class="form-control" required placeholder="Masukan Sumber dana" required>
          </div>
           <div class="form-group">
                <label for="">Tanggal masuk</label>
                <input type="date" name="tanggal_masuk" class="form-control" required>
            </div>
             
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
</div>

<?php $__env->startPush('scripts'); ?>
  <script type="text/javascript">
        $(document).ready(function() {
	var max_fields      = 100; //maximum input boxes allowed
	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
  var add_button      = $(".add_field_button"); //Add button ID
	
	var x = 1; //initlal text box count
	$(add_button).click(function(e){ //on add input button click
		e.preventDefault();
		if(x < max_fields){ //max input box allowed
			x++; //text box increment
      
			$(wrapper).append('<div><table><tr><td><select name="id_barang[]" id="" class="form-control"><option selected disabled>-----Pilih Jenis Barang-----</option><?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($j->id_barang); ?>"><?php echo e($j->nama_barang); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div></td><td class="pl-2"><input type="number" name="jumlah[]" id="txt1[]" onkeyup="sum();" class="form-control" required placeholder="Masukan Jumlah" required></td><td class="pl-2"><input type="number" name="harga_satuan[]" id="txt2[]" onkeyup="sum();" class="form-control" required placeholder="Masukan Jumlah" required></td><td class="pl-2"><input type="number" name="harga_total[]" id="txt3[]" class="form-control" required placeholder="Masukan Jumlah" required></td><td class="pl-2"><input type="text" name="nama_toko[]" class="form-control" required placeholder="Masukan Jumlah" required></td><td class="pl-2"><input type="text" name="merek[]" class="form-control" required placeholder="Masukan Jumlah" required></td></tr></table><a href="#" class="remove_field">Remove</a></div>');
		}
  });
  

	
	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
		e.preventDefault(); $(this).parent('div').remove(); x--;
	})
});

function sum() {
      var txtFirstNumberValue = document.getElementById('txt1[]').value;
      var txtSecondNumberValue = document.getElementById('txt2[]').value;
      var result = parseFloat(txtFirstNumberValue) * parseFloat(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('txt3[]').value = result;
      }
}

</script>

  <?php $__env->stopPush(); ?>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/keranjang_masuk/input.blade.php ENDPATH**/ ?>