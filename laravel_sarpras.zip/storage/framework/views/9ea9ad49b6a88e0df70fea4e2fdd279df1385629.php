 <?php $__env->startSection('content'); ?>
<title>Data Admin</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Data Admin</h6>
</div>
<div class="card-body">
    <div class="table-responsive">
        <div>
             <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="help-block">
                                <strong style="color:red"><?php echo e($message); ?></strong>
                            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <br>
             <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                            <span class="help-block">
                                <strong style="color:red"><?php echo e($message); ?></strong>
                            </span>
                       
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
         
        <button class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>
        <br>
        <br>
        <table id="dataTable" class="table table-bordered" cellspacing="0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Level</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="data-row">
                    <td class="align-middle iteration"><?php echo e(++$i); ?></td>
                    <td class="align-middle name"><?php echo e($u->name); ?></td>
                     <td class="align-middle name"><?php echo e($u->email); ?></td>
                    <td class="align-middle username"><?php echo e($u->username); ?></td>
                    <td class="align-middle password">Password Tidak Ditampilkan</td>
                    <td class="align-middle level"><?php echo e($u->level); ?></td>
                   
                    <td>
                        <div class="row">
                                <a href="/user/edit/<?php echo e($u->id); ?>" class="btn btn-primary btn-sm ml-2">Edit</a>
                            <form action="<?php echo e(route('user.destroy',$u->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm ml-2">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div id="tambah" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Masukan Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('user.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" name="name" class="form-control" required placeholder="Masukan Nama">
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="email" class="form-control" required placeholder="Masukan mail">
                      
                    </div>
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="username" class="form-control" required placeholder="Masukan Username">
                      
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" name="password" class="form-control" required placeholder="Masukan Password">
                    </div>
                    <input type="hidden" name="level" value="admin">
                 
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\software\xampp\htdocs\laravel_sarpras\resources\views/user/view.blade.php ENDPATH**/ ?>