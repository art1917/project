<?php $__env->startSection('content'); ?>
<title>Edit Data Users</title>
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
            <form action="/user_pj/update" method="post">
                    <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label for="">Nama</label>
                      <input type="hidden" name="id" class="form-control" value="<?php echo e($user2->id); ?>" required placeholder="Masukan Nama">
                      <input type="text" name="name" class="form-control" value="<?php echo e($user2->name); ?>" required placeholder="Masukan Nama">
                  </div>
                  <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="username" class="form-control" value="<?php echo e($user2->username); ?>" required placeholder="Masukan Username">
                  </div>
                   <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e($user2->email); ?>" required placeholder="Masukan email">
                  </div>
                 
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div> 
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\xampp\htdocs\laravel_sarpras\resources\views/pj/edit.blade.php ENDPATH**/ ?>