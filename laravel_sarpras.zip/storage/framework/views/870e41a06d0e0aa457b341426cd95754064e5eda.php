 <?php $__env->startSection('content'); ?>
<title>Edit Data</title>
<div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
        <form action="/masuk/update" method="post">
            <?php echo e(csrf_field()); ?>

            
            <div class="form-group">
                <label for="">Barang</label>
                <input type="hidden" name="id_masuk" value="<?php echo e($masuk2->id_masuk); ?>">
                 <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($masuk2->id_barang==$r->id_barang): ?>
                  <input value="<?php echo e($r->id_barang); ?>" type="hidden" class="form-control" name="id_barang">
                  <input value="<?php echo e($r->nama_barang); ?>" type="text" class="form-control" name="" readonly>
                      <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>

            <div class="form-group">
                <label for="">Jumlah</label>
                <input type="number" name="jumlah" class="form-control" value="<?php echo e($masuk2->jumlah_asup); ?>" required placeholder="Masukan Jumlah">
            </div>
           
            <div class="form-group">
                <label for="">Tanggal Keluar</label>
                <input type="date" name="tanggal_masuk" class="form-control" value="<?php echo e($masuk2->tanggal_masuk); ?>" required>
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\xampp\htdocs\laravel_sarpras\resources\views/masuk/edit.blade.php ENDPATH**/ ?>